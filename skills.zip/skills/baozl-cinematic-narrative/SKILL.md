---
name: baozl-cinematic-narrative
description: 风格包含：清冷夏日插画、童话巨宠插画。用于收集用户指定的主体和具体风格，将主体原样填入对应固定配方并直接生成图片；不得展示提示词、扩写动作、场景或叙事。
metadata:
  author: "baozl.com"
  email: "647015850@qq.com"
  homepage: "https://baozl.com"
  emoji: "🎬"
version: 0.1.0
display_name: "宝藏郎·电影叙事插画"
display_name_en: "Baozl Cinematic-Narrative"
description_zh: "宝藏郎·电影叙事插画 · 由 baozl.com 提供。含清冷夏日、童话巨宠 2 种风格，套用固定配方直接生成图片。"
description_en: "Baozl Cinematic-Narrative illustration (by baozl.com): cool summer, giant pet."
visibility: "public"

---

# 宝藏郎·电影叙事插画

使用 references/recipes.md 中的固定配方。参考图位于 assets/，只用于核对对应风格。

## 必填检查

生成前必须取得：

1. 用户亲自指定的主体内容。
2. 以下具体风格之一：“清冷夏日插画”、“童话巨宠插画”。

缺主体时，只问：请先告诉我想画的主体内容。

缺具体风格时，只列出上述风格并请用户选择。不要代替用户选择后直接生成。

## 固定配方流程

1. 读取 references/recipes.md 并找到用户所选的同名配方。
2. 复制固定配方全文。
3. 仅把【主体内容】替换为用户提供的主体原文。
4. 不润色主体，不补动作、场景、服装、道具、构图或故事，不删除配方内容。
5. 不混用其他配方的词语。用户另有明确画幅或硬性限制时，仅原样追加在配方末尾。
6. 将替换后的完整配方作为内部提示词，立即调用图像生成工具并直接返回图片。

## 输出限制

- 两个必填项未齐全时，不输出提示词，不调用生成工具。
- 不输出多个候选版本。
- 不向用户展示、复述或总结内部提示词。
- 不另写负面提示词；固定配方内已有的负面约束保持不变并仅供生成工具使用。
- 不解释内部选择和替换过程。
